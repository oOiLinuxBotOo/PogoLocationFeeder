# PogoLocationFeeder
Json feed of pokemon location data

We have been contacted by Discord regarding server load issues. They will be blocking old bot accounts, and new feed requests have been migrated to a centralized server to allow for better traffic control. We will be opening up donations toward hosting a dedicated server, aimed at providing correct feed outputs for pokemon moves, IVs, and expiration dates.

[paypal](https://www.paypal.com/en_US/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=QZCKGUUQ9RYPY)

[Download latest Release](https://github.com/5andr0/PogoLocationFeeder/releases/latest "5andr0/PogoLocationFeeder/releases/latest")
